package opg1;

public class FizzBuzzTester {

	public static void main(String[] args) {
		FizzBuzz.DoFizzBuzz(new int[] {3, 5, 15});
	}

}
